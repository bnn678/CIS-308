int Min(int*, int);
int Max(int*, int);
double avg(int*, int);